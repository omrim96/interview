# Home Assignment 
In order to use the MagicList, you can execute MagicList/test_magic_list.py, or simply import this class from magic_list
and try it by yourself.

In order to run API webserver, execute the "converter_webserver.py" file. In order to test it you can execute the 
example file
